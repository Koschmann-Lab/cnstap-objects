function cnstap(){


  var weights={
    clonalityweight:5,
    tierscoreweight:3,
    trialweight:20,

  }

  return JSON.stringify(weights);

}
